=== Maestro Telegram Chat ===
Contributors: vipersone
Tags: telegram, chat, contact form, support, widget
Requires at least: 5.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.4.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Maestro Telegram Chat adds a floating chat/contact widget that sends messages from your WordPress site directly to Telegram.

== Description ==

Maestro Telegram Chat is a lightweight, flexible chat widget for WordPress that forwards messages directly to your Telegram bot.

* Floating chat widget (bottom left or right)
* Shortcode [maestro_telegram_chat] to embed the form into any page or post
* Sends messages to private chats, groups or channels
* Customizable texts, placeholders, success and error messages
* Custom button: text or image (PNG/SVG/GIF)
* Color and font customization
* Built-in step-by-step integration guide inside the admin menu
* Pseudo-localization for 7 languages (based on site locale): English, Russian, Ukrainian, Polish, German, French, Spanish

== Installation ==

1. Upload the plugin ZIP via `Plugins → Add New → Upload Plugin`.
2. Activate the plugin.
3. Go to `Maestro Chat → Settings` and configure:
   * Bot Token (from @BotFather)
   * Chat ID (via @userinfobot or `getUpdates`)
4. Enable the floating widget or use the shortcode `[maestro_telegram_chat]` inside your pages or posts.

== Changelog ==

= 1.4.1 =
* Added plugin icons and banner assets.
* Updated plugin header and metadata.

= 1.4.0 =
* Added design and position settings (left/right, custom colors, font family).
* Added tabbed settings: Integration, Texts, Design, Messages.
* Added custom button image support.
* Added localized admin UI strings for EN/RU/UK/PL/DE/FR/ES.
